OpenGL_Robot

[Site glut](http://ultrafil.free.fr/fr/tutoriaux%20opengl%20fr/formes.html)

![](https://ratchet-galaxy.com/image/fr/jeux/ps2/ratchet-and-clank-3/encyclopedie/personnages/4325-clank-2553.png)
![](https://ratchet-galaxy.com/image/fr/jeux/ps3/ratchet-and-clank-operation-destruction/encyclopedie/personnages/5035-clank-3301.png)
![](https://i.pinimg.com/originals/59/ca/27/59ca27890301c845b7bafff0aca52e58.jpg)
