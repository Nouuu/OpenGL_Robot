#ifndef SKYBOX_H
#define SKYBOX_H


class Skybox
{
    public:
        Skybox();
        virtual ~Skybox();
    protected:
    private:
};

#endif // SKYBOX_H
